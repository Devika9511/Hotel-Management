Hotel Management - Swing version
--------------------------------
Files:
 - Room.java, Food.java, Customer.java, Booking.java, Hotel.java, Main.java

How to compile and run (from project dir):
    javac *.java
    java Main

Data persistence:
 - The app saves a serialized file 'hotel_data.ser' in the working directory when you click 'Save Data' or on actions that call save.
 - If 'hotel_data.ser' exists, the app will load it on startup.

This is a simple example for small demos. For production, consider using a database and better error handling.